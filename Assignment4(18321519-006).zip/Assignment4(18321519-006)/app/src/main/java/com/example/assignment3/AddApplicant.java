package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddApplicant extends AppCompatActivity {

    EditText etName;
    EditText etCNIC;
    EditText etEmail;
    EditText etPhone;
    Button addButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_applicant);

        etName = findViewById(R.id.studentname);
        etCNIC = findViewById(R.id.studentCnic);
        etEmail = findViewById(R.id.studentEmail);
        etPhone = findViewById(R.id.studentphone);
        addButton = findViewById(R.id.addbutton_student);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applicant_DBHelper myDB = new applicant_DBHelper(AddApplicant.this);
                myDB.addApplicant(etName.getText().toString().trim(),
                        etCNIC.getText().toString().trim(),
                        etEmail.getText().toString().trim(),
                        etPhone.getText().toString().trim());
            }
        });
    }
}